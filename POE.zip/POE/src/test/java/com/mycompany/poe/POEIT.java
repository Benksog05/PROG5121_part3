/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author NJOUMESSI
 */
public class POEIT {
    
    public POEIT() {
    }

    @Test
    public void testMain() {
        System.out.println("main");
        String[]args = null;
        POE.main(args);
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        POE.registerUser();
         //TODO review the genrated test code and remove the default call to fail.
         fail("The test case is a prototype.");
    }

    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        boolean expResult = false;
        boolean result = POE.loginUser();
        assertEquals(expResult, result);
        //TODO review the genrated test code and remove the default call to fail.
         fail("The test case is a prototype.");
    }

    @Test
    public void testRunMainMenu() {
        System.out.println("runMainMenu");
        POE.runMainMenu();
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testSendMessages() {
        System.out.println("sendMessages");
        POE.sendMessages();
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testMessageManagerMenu() {
        System.out.println("messageManagerMenu");
        POE.messageManagerMenu();
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testDisplaySendersAndRecipients() {
        System.out.println("displaySenderAndRecipients");
        POE.displaySendersAndRecipients();
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testDisplayLongestMessage() {
        System.out.println("displayLongestMessage");
        POE.displayLongestMessage();
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testSearchByMessageID() {
        System.out.println("searchByMessageID");
        String id = "";
        POE.searchByMessageID(id);
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testSearchByRecipient() {
        
    }

    @Test
    public void testDeleteByMessageHash() {
        System.out.println("deleteByMessageHash");
        String hash = "";
        POE.deleteByMessageHash(hash);
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        POE.displayReport();
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        
    }

    @Test
    public void testGenerateMessageID() {
        System.out.println("generatedMessageID");
        String expResult = "";
        String result = POE.generateMessageID();
        assertEquals(expResult, result);
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = "";
        int num = 0;
        String msg = "";
        String expResult = "";
        String result = POE.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        //TODO review the genrated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    @Test
    public void testDisplayMessageDetails() {
    }

    @Test
    public void testWriteMessageToJSON() {
    }
    
}
